-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2020 at 07:41 PM
-- Server version: 10.3.16-MariaDB
-- PHP Version: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `multi_level`
--

-- --------------------------------------------------------

--
-- Table structure for table `intrusions`
--

CREATE TABLE `intrusions` (
  `id` int(11) NOT NULL,
  `intrusion_email` varchar(40) NOT NULL,
  `intruder_password` varchar(20) NOT NULL,
  `intrusion_date` varchar(20) NOT NULL,
  `intrusion_time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `intrusions`
--

INSERT INTO `intrusions` (`id`, `intrusion_email`, `intruder_password`, `intrusion_date`, `intrusion_time`) VALUES
(2, 'bmhseruwa@mail', 'Baptistmodel_12', '16:Apr:2020', '19:15:08');

-- --------------------------------------------------------

--
-- Table structure for table `login_log`
--

CREATE TABLE `login_log` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `date_of_login` varchar(30) NOT NULL,
  `time_of_login` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login_log`
--

INSERT INTO `login_log` (`id`, `email`, `date_of_login`, `time_of_login`) VALUES
(1, 'ola@gmail.com', '16:Apr:2020', '19:32:45');

-- --------------------------------------------------------

--
-- Table structure for table `logout_log`
--

CREATE TABLE `logout_log` (
  `id` int(11) NOT NULL,
  `email` varchar(40) NOT NULL,
  `date_of_logout` varchar(20) NOT NULL,
  `time_of_logout` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `logout_log`
--

INSERT INTO `logout_log` (`id`, `email`, `date_of_logout`, `time_of_logout`) VALUES
(1, 'ola@gmail.com', '16:Apr:2020', '19:40:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(300) NOT NULL,
  `phone` varchar(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `pwd` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `phone`, `email`, `pwd`) VALUES
(1, 'Enoch', '08074309999', 'ola@gmail.com', 'LORDJESUS'),
(2, 'bmhseruwa', '0', 'a@mail.com', 'aa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `intrusions`
--
ALTER TABLE `intrusions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_log`
--
ALTER TABLE `login_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logout_log`
--
ALTER TABLE `logout_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `intrusions`
--
ALTER TABLE `intrusions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `login_log`
--
ALTER TABLE `login_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `logout_log`
--
ALTER TABLE `logout_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
