<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=pages/index.php">
<title>Multi-Level IDS</title>
<script language="javascript">
    window.location.href = "login/index.php"
</script>
</head>
<body>
Go to <a href="login/index.php">/login/index.php</a>
</body>
</html>
