<!--A Design by Olayode Enoch Oladapo
   Author: Olayode Enoch Oladapo
   -->
<!DOCTYPE html>
<html lang="en">
   <head>
      <title>MULTI-LEVEL IDS AND LOG MANAGEMENT :: Signup/Signin </title>
      <!-- Meta tags -->
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
      <meta name="keywords" content="Multi-Level, Intrusion Detection System, Log Management"
         />
      <script>
         addEventListener("load", function () { setTimeout(hideURLbar, 0); }, false); function hideURLbar() { window.scrollTo(0, 1); }
      </script>
      <!-- Meta tags -->
      <!--stylesheets-->
      <link href="css/style.css" rel='stylesheet' type='text/css' media="all">
      <!--//style sheet end here-->
      <link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:400,600,700" rel="stylesheet">
   </head>
   <body>
      <div class="mid-class">
         <div class="art-right-w3ls">
            <h2>Sign In and Sign Up</h2>
            <form action="login.php" method="post">
               <div class="main">
                  <div class="form-left-to-w3l">
                     <input type="email" name="email" placeholder="Email" required="">
                  </div>
                  <div class="form-left-to-w3l ">
                     <input type="password" name="password" placeholder="Password" required="">
                     <div class="clear"></div>
                  </div>
                  <input type="hidden" name="date" value="<?php echo dats()?>" required="">
                  <input type="hidden" name="time" value="<?php echo tim()?>" required="">
               </div>
               <div class="left-side-forget">
                  <input type="checkbox" class="checked">
                  <span class="remenber-me">Remember me </span>
               </div>
               <div class="right-side-forget">
                  <a href="../admin/html/index.php" class="for"><strong>-> ADMIN PANEL</strong></a>
               </div>
               <div class="clear"></div>
               <div class="btnn">
                  <button type="submit" name="login">Sign In</button>
               </div>
            </form>
            <div class="w3layouts_more-buttn">
               <h3>Don't Have an account..?
                  <strong><a href="#content1">Sign Up Here
                  </a></strong>
               </h3>
            </div>
            <!-- popup-->
            <div id="content1" class="popup-effect">
               <div class="popup">
                  <!--login form-->
                  <div class="letter-w3ls">
                     <form method="post" action="signup.php">
                        <div class="form-left-to-w3l">
                           <input type="text" name="username" placeholder="Username" required="">
                        </div>
                        <div class="form-left-to-w3l">
                           <input type="text" name="phone" placeholder="Phone" required="">
                        </div>
                        <div class="form-left-to-w3l">
                           <input type="email" name="email" placeholder="Email" required="">
                        </div>
                        <div class="form-left-to-w3l">
                           <input type="password" name="password" id="password1" placeholder="Password" required="">
                        </div>
                        <div class="form-left-to-w3l margin-zero">
                           <input type="password" id="password2" placeholder="Confirm Password" required="">
                        </div>
                        <div class="btnn">
                           <button name="submit_form" type="submit">Sign Up</button>
                           <br>
                        </div>
                     </form>
                     <div class="clear"></div>
                  </div>
                  <!--//login form-->
                  <a class="close" href="#">&times;</a>
               </div>
            </div>
            <!-- //popup -->
         </div>
         <div class="art-left-w3ls">
            <h1 class="header-w3ls">
               Multi-Level Intrusion Detection System and Log Management
            </h1>
         </div>
      </div>
      <footer class="bottem-wthree-footer">
         <p>
            © <script>document.write(new Date().getFullYear());</script> Multi-Level IDS and Log Management. All rights reserved | Design by
           Olayode Enoch Oladapo
         </p>
      </footer>
   </body>
   <!-- script for password match -->
   <script>
        window.onload = function () {
            document.getElementById("password2").onchange = validatePassword;
            document.getElementById("password1").onchange = validatePassword;
        }

        function validatePassword() {
            var pass1 = document.getElementById("password1").value;
            var pass2 = document.getElementById("password2").value;
            if (pass1 != pass2)
                document.getElementById("password2").setCustomValidity("Passwords Don't Match");
            else
                document.getElementById("password2").setCustomValidity('');
            //empty string means no validation error
        }
    </script>
    <!-- //script for password match -->

<!-- Date and time generating function -->
<?php
function dats(){
	$time = time();
	$actual_time =date('d:M:Y', $time);
	
	echo $actual_time;	
}
function tim(){
	$time = time();
	$actual_time =date('H:i:s', $time);
	
	echo $actual_time;	
}
?>
<!--//Date and time generating function -->

</html>