<?php
require_once "../required/connect.php";
require_once "../required/core.php";
require_once "../required/function.php";

 if (isset($_POST['login'])){
		$email = data_input($_POST['email']);
		$password = data_input($_POST['password']);
        $date = data_input($_POST['date']);
        $time = data_input($_POST['time']);
        
		$query = "SELECT * FROM users WHERE email='$email' AND pwd='$password'";
		$result = $connect->query($query);
        $user_data=mysqli_fetch_assoc($result);

        if ($result->num_rows == 0) {
                $query1 = "INSERT INTO intrusions (intrusion_email, intruder_password, intrusion_date, intrusion_time)
                VALUE('$email','$password','$date','$time')";
                if ($connect->query($query1) === TRUE) {
				header("refresh:1;index.php");
				echo("<script> alert('Invalid Login Details! Please Enter Correct Details!');</script>");	
            } else {
                echo "Error!!!";
            }
        }else if ($result->num_rows == 1) {
                $query2 = "INSERT INTO login_log (email, date_of_login, time_of_login)
                VALUE('$email','$date','$time')";
                if ($connect->query($query2) === TRUE) {
				$user_id = $user_data['id'];
				$_SESSION['username'] = $username;
				$_SESSION['email'] = $email;
				$_SESSION['id'] = $id;
				$_SESSION['loggedIn'] = true;
				$_SESSION['user_id']=$user_id;
				header('Location: ../main/index.php');
            } else {
                echo "Error!!!";
            }
			}
		}
?>