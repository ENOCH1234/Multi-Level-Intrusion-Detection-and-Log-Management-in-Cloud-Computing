	<?php
	require_once("../required/connect.php");
	require_once("../required/function.php");
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\Exception;

ob_start();

	if (isset($_POST['submit_form'])){
        $username = data_input($_POST['username']);
        $phone = data_input($_POST['phone']);
		$email = data_input($_POST['email']);
		$password = data_input($_POST['password']);
		
		$queryy ="SELECT * FROM users WHERE username='$username'";
					$result = $connect->query($queryy);

				if ($result->num_rows > 1) {
				echo("<script> alert('The username ".$username." already exists, kindly register with another Username');</script>");
					header("refresh:1;index.php");
				}else{
		
		$query1 ="SELECT * FROM users WHERE email='$email'";
		$result = $connect->query($query1);

				if ($result->num_rows > 1) {
				echo("<script> alert('The Email ".$email." already Exists, kindly register with another email address');</script>");
					header("refresh:1;index.php");
				}else{
					
				$query2 = "INSERT INTO users (username, phone, email, pwd)
				VALUE('$username','$phone','$email','$password')";
				
				if (mysqli_query($connect, $query2)) {
		
					$message = "
						<br>
						<br>
						<p><b>REGISTRATION DETAILS:</b></p>
						<p><i>Username:</i> <b>".$_POST['username']."</b></p>
						<br>
						<p><i>Email:</i> <b>".$_POST['email']."</b></p>
						<br>
						<p><i>Password:</i> <b>".$_POST['password']."</b></p>
						<br>
						";

					//Load phpmailer
		    		require 'vendor/autoload.php';

		    		$mail = new PHPMailer(true);                             
				    try {
				        //Server settings
				        $mail->isSMTP();                                     
				        $mail->Host = 'smtp.gmail.com';                      
				        $mail->SMTPAuth = true;                               
				        $mail->Username = 'kingdomtube01@gmail.com';     
				        $mail->Password = 'LORDJESUS';                    
				        $mail->SMTPOptions = array(
				            'ssl' => array(
				            'verify_peer' => false,
				            'verify_peer_name' => false,
				            'allow_self_signed' => true
				            )
				        );                         
				        $mail->SMTPSecure = 'ssl';                           
				        $mail->Port = 465;                                   

				        $mail->setFrom('kingdomtube01@gmail.com');
				        
				        //Recipients
				        $mail->addAddress($email);              
				        $mail->addReplyTo('kingdomtube01@gmail.com');
				       
				        //Content
				        $mail->isHTML(true);                                  
				        $mail->Subject = 'Cloud System Registration';
				        $mail->Body    = $message;

				        $mail->send();
                        unset($_SESSION['email']);
						echo("<script> alert('You have successfully registered, kindly Log In to proceed. A message has been sent to your mail containing vital information, do well to check it!');</script>");
					    header("refresh:1;index.php");
				    } 
				    catch (Exception $e) {
                        
                        echo("<script> alert('You have successfully registered, kindly Log In to proceed.
						But, message could not be sent');</script>");
						header("refresh:1;index.php");
				    }


	}
	}}}
?>