<!--A Design by Olayode Enoch Oladapo
   Author: Olayode Enoch Oladapo
   -->

<?php
require_once "../required/connect.php";
require_once "../required/core.php";

if (isset($_SESSION["user_id"])){
	$username = getusersfield($connect, 'username');
	$email = getusersfield($connect, 'email');
}
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Cloud Hosting Compare | Home :: Cloud</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="css/slider.css" rel="stylesheet" type="text/css" media="all"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,600,700,400' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Raleway:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
<script type="text/javascript" src="js/jquery.min.js"></script>
<script src="js/jquery.easydropdown.js"></script>
<script type="text/javascript" src="js/script.js"></script>
 <script type="text/javascript" src="js/jquery.nivo.slider.js"></script>
 <script src="js/jquery.magnific-popup.js" type="text/javascript"></script>
 <link href="css/magnific-popup.css" rel="stylesheet" type="text/css">
 <script type="text/javascript">
    $(window).load(function() {
        $('#slider').nivoSlider();
    });
    </script>    
</head>
<body>
  <div class="header" id="home">
  	  <div class="header_top">
	   <div class="wrap">
		 	     <div class="logo">
						<a href="index.html"><img src="images/logo.png" alt="" /></a>
					</div>	
						<div class="menu">
						    <ul>
						    	<li class="current"><a href="#section-1" class="scroll"> Compare Hosting Providers</a></li>
								<li><a href="#section-2" class="scroll">About</a></li>
								<li><a href="#section-3" class="scroll">How it works</a></li>
								<li><a href="#section-4" class="scroll">Contact</a></li>
								<li class="login" >
									<div id="loginContainer"><a href="#" id="loginButton"><span class="fa fa-user">Welcome, <?php echo $username; ?>!</span></a>
									<div id="loginBox">                
						                    <form id="loginForm" method="POST" action="logout.php">
						                        <fieldset id="body">
						                        	<input type="hidden" name="email" value="<?php echo $email ?>">
						                            <input type="hidden" name="date" value="<?php echo dats(); ?>">
						                            <input type="hidden" name="time" value="<?php echo tim(); ?>">
													<input type="submit" id="login" name="signout" value="Sign Out">
													<label for="checkbox"> <i class="fa fa-smile-o"> Thank you!</i></label>
						                        </fieldset>
						                    </form>
						                </div>
						            </div>
								</li>
								<div class="clear"></div>
							</ul>
						</div>							
	    		 <div class="clear"></div>
	        </div>
	    </div>
	 </div>			      	
     <div class="main" id="container">
	 	<div class="content">	
	 		 <div class="content_top section" id="section-1">  
	 		     <div class="wrap">                                  		
            	   <div class="banner_desc">
            	      <div class="wmuSlider example1">
							<div class="wmuSliderWrapper">
							<article><p>Find the right cloud Hosting Without the Fluffy  white stuff</p> <img src="images/clouds.png"  alt="" /> </article>
							<article><p>Get anything remotely on the cloud with cloud hosting</p> <img src="images/system.png"  alt="" /> </article>
							<article><p>Compare cloud hosting packages that best suits your purpose</p> <img src="images/slider-img3.png"  alt="" /> </article>
							<article><p>Never abandon the World Wide Web - You are on...</p> <img src="images/slider-img4.png"  alt="" /> </article>
							</div>
                       </div>
            	      <script src="js/jquery.wmuSlider.js"></script> 
						<script type="text/javascript" src="js/modernizr.custom.min.js"></script> 
						<script>
       						 $('.example1').wmuSlider();         
   						 </script> 	   
   						         	      
            		<div class="dropdown-buttons">   
            		  <div class="dropdown-button">           			
            			<select class="dropdown" tabindex="9" data-settings='{"wrapperClass":"flat"}'>
            			<option value="0">Diskspace Amount</option>	
						<option value="1">100 GB</option>
						<option value="2">200 GB</option>
						<option value="3">500 GB</option>
						<option value="4">700 GB</option>
						<option value="5">900 GB</option>
						<option value="6">1 TB</option>
						<option value="7">5 TB</option>
						<option value="8">10 TB</option>
					  </select>
					</div>
				     <div class="dropdown-button">
					  <select class="dropdown" tabindex="9" data-settings='{"wrapperClass":"flat"}'>
            			<option value="0">Operating System</option>	
						<option value="1">Linux</option>
						<option value="2">Windows</option>
						<option value="3">Solaris</option>
						<option value="4">Mac</option>
						<option value="5">Unix</option>
						<option value="5"></option>
						<option value="5"></option>
					  </select>
					 </div>
				   </div>          		
                 		 <div class="quote_button">
                  	 		<a class="popup-with-zoom-anim" href="#small-dialog">+ Get a quote Now</a>
                  	 				<div id="small-dialog" class="mfp-hide">
					                       <div class="priceing-tabel">
												<div class="priceing-header">
													<h4>Windows</h4>
													<a href="#">100 GB<label>$29/month</label></a>
												</div>
												<ul>
													<li><a href="#">15 Email Accounts</a></li>
													<li><a href="#">100 GB space</a></li>
													<li><a href="#">1 Domain Name</a></li>
													<li><a href="#">500 GB Bandwith</a></li>
												</ul>
												<a class="price-btn" href="#">Order Now</a>
											</div>
										</div>
                 				 </div>                
              				</div>
          				</div>
        		<div class="comment_icons">
                	<ul>
                		<li><a class="comments" href="#"> <span>340 Comments</span> </a></li>
                		<li><a class="email" href="#"> <span>896 Shares</span> </a></li>
                		<li><a class="like" href="#"> <span>1050 Likes</span> </a></li>
                	</ul>
                </div>
     		 </div>
                       
           <div class="about_desc section" id="section-2"> 
              <div class="wrap">            
                 	<div class="section group example">
						<div class="col_1_of_2 span_1_of_2">
						   <h3>We use 100% Real Clouds</h3>
						   <p><span>The underlying network infrastructure of a cloud, being an important component of the computing environment, can be the object of an attack. Grid and cloud applications running on compromised hosts are also a security concern. Cloud systems are susceptible to all typical network and computer security attacks, plus specific means of attack because of their new protocols and services.</p>
						   <p>IDSs are software or hardware systems that automate the process of monitoring the events occurring in a computer system or network, analyzing them for signs of security problems. IDSs are one of widely used security technologies. An IDS alerts to system administrators, generate log about attack when it detects dangerous signatures according to host or network security policy. Thus, the aim of the IDS is to alert or notify the system that some malicious activities have taken place and try to eliminate it.</p>

		 				</div>
						<div class="col_1_of_2 span_1_of_2">
						   <h3>About the Developer</h3>
						   <center><img src="images/eno.jpg" width="45%"></center>
						   <p><span><b>Olayode Enoch Oladapo</b></span> is a 300 level student from Computer Science Department, Adekunle Ajasin University, Akungba Akoko, Ondo State, Nigeria. This project work is one of his works as his passion trends in Computer Science and providing solutions to earth issues with Tech Initiatives.</p>
						</div>
				    </div>	        
           	  </div>             
       	  </div>  
       	  
       	    <div class="features section" id="section-3">      	      	      	   	
       	   	 	<h2>How it Works</h2>
       	   
       	    <!------ Slider ------------>	 
       	    <div class="browser">  	       
       	   	    <div id="mySliderTabsContainer">
	               <div id="mySliderTabs">
	               <ul>
	                <li><a class="cloud_icon" href="#mother"><i class="cloud_icon"> </i></a></li>
	                <li><a class="cross" href="#parks">  <i class="cross"> </i> </a></li>
	                <li><a class="bubble" href="#theOffice"><i class="bubble"> </i></a></li>
	                <li><a class="right_arrow" href="#southPark"> <i class="right_arrow"> </i></a></li>
	              </ul>
	              <div id="mother">
	              	<img src="images/browser1.png" alt="" />
	              </div>
	              <div id="parks">
	                 <img src="images/browser2.png" alt="" />
	              </div>
	              <div id="theOffice">
	              	<img src="images/browser3.png" alt="" />
	              </div>
	              <div id="southPark">
	              	<img src="images/browser4.png" alt="" />
	              </div>             
	            </div>
	            <div class="clear"></div>
	          </div>
          </div>
            <link rel="stylesheet" href="css/jquery.sliderTabs.min.css">
			<script src="js/jquery.sliderTabs.min.js"></script> 
			<script>
				 $(document).ready(function(){
				      var tabs = $("div#mySliderTabs").sliderTabs({
				        autoplay:5000,
				        indicators: true,
				        panelArrows: true,
				        panelArrowsShowOnHover: true
				      });      
				/*      $("#mySliderTabsContainer").resizable({
				        maxHeight: 200,
				        minHeight: 200,
				        maxWidth: 605
				      });
				*/
				      prettyPrint();
				    });
				
				    $(document).delegate(".nav-list li a", "click", function(){
				      $(this).parent().siblings().removeClass("active");
				      $(this).parent().addClass("active");
				    });	
			</script>
		    <!------End Slider ------------>
       	   </div>  
       	 </div>
      </div>
     <div class="footer section"  id="section-4">
     	 <div class="wrap">
     	 	      <div class="section group example">
						<div class="col_1_of_2 span_1_of_2">
							<div class="footer_logo">
							 <img src="images/logo.png" alt="" />
							</div>
						      <p>Get updated on new product and services. Never miss out on promos and special offers.</p>
                                <div class="search_box"> 		    		 	
									 <form>
										<input type="text" class="textbox" value="Leave your email address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Leave your emil cobber';}">
								        <input type="submit" value="Submit">
							         </form>
							     </div>
		 				</div>
						<div class="col_1_of_2 span_1_of_2">
						    <div class="social_icons">
				       	      	<ul>
				       	    	 <li><a class="rss" href="#"></a> </li>
				       	    	  <li><a class="dribble" href="#"></a> </li>
				       	    	   <li><a class="twitter" href="https://twitter.com/" target="_blank"> </a> </li>
				       	    	    <li><a class="facebook" href="https://www.facebook.com/" target="_blank"> </a> </li>
				       	    	    <div class="clear"></div>
				       	    	 </ul>
				       	        </div>
				       	   </div>   
     				 </div>
     			</div>		
			 </div>
			 
			<footer class="footer">
			<center>
				<p class="pclass">© <script>document.write(new Date().getFullYear());</script> Multi-Level IDS and Log Management. All rights reserved | Designed by
            Olayode Enoch Oladapo (AAUA)</p>
			</center>
			</footer>
	</body>

<!-- Date and time generating function -->
<?php
function dats(){
	$time = time();
	$actual_time =date('d:M:Y', $time);
	
	echo $actual_time;	
}
function tim(){
	$time = time();
	$actual_time =date('H:i:s', $time);
	
	echo $actual_time;	
}
?>
<!--//Date and time generating function -->

<!-- Footer Style -->
<style>
	.footer{
		background:black;
		color:white;
	}
	
</style>
<!-- Footer Style -->
</html>