<?php
require_once "../required/connect.php";
require_once "../required/core.php";
require_once "../required/function.php";

 if (isset($_POST['signout'])){
		$email = data_input($_POST['email']);
        $date = data_input($_POST['date']);
        $time = data_input($_POST['time']);

        $sql = "INSERT INTO logout_log (email, date_of_logout, time_of_logout)
        VALUES ('$email', '$date', '$time')";

        if ($connect->query($sql) === TRUE) {
            session_unset();
            header('Location: ../index.php');
        } else {
            echo "Error: " . $sql . "<br>" . $connect->error;
        }}
?>